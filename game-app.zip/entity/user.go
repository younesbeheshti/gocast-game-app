package entity

type User struct {
	ID             uint
	PhoneNumber    string
	Name           string
	HashedPassword string
	Role           Role
}
